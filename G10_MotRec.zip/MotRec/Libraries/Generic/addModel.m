function Models = addModel(Models,NewModel)
    Models = [Models;NewModel];
end